import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listado',
  templateUrl: './listado.component.html',
  styleUrls: ['./listado.component.scss']
})
export class ListadoComponent implements OnInit {

  productos = [
    { id: 1, nombre: 'Camisa', precio: 25.00 },
    { id: 2, nombre: 'Pantalón', precio: 40.00 },
    { id: 3, nombre: 'Zapatos', precio: 60.00 }
  ];

  constructor() { }

  ngOnInit(): void {
    // Aquí podrías cargar productos desde una API si lo deseas más adelante
  }

}
